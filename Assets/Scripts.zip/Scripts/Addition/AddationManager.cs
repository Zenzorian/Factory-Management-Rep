using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace FactoryManager
{
    public class AddationManager : MonoBehaviour
    {
        [SerializeField] private ChioceListAddation _chioceListAddation;

        public void AddChioceList() 
        {
            _chioceListAddation.SetList(ChoiceOfCategoryMenu.MenuType);
        }

    }
}