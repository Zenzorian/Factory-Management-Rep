using System.Collections.Generic;
using UnityEngine;

namespace FactoryManager
{ 
    [System.Serializable]
    public class ChioceListAddation
    {
        [SerializeField] private Transform additionPanel;
        [SerializeField] private Transform _content;
        [SerializeField] private InputFieldCreator _inputFieldCreator = new InputFieldCreator();

        private List<string> _list;
        public void SetList(MainMenuTypes types)
        {
            switch (types)
            {
                case MainMenuTypes.Workspace:
                    _list = GlobalData.typesOfWorkspaces;
                    BuildAddationPanel(types);
                    break;
                case MainMenuTypes.Tools:
                    _list = GlobalData.typesOfTools;
                    BuildAddationPanel(types);
                    break;
                case MainMenuTypes.Workers:
                    _list = GlobalData.typesOfWorkers;
                    BuildAddationPanel(types);
                    break;
                case MainMenuTypes.Parts:
                    _list = GlobalData.typesOfParts;
                    BuildAddationPanel(types);
                    break;
                default:
                    break;
            }


        }
        private void BuildAddationPanel(MainMenuTypes menuTypes) 
        {
            Clear();

            string title = menuTypes.ToString();

            _inputFieldCreator.Create(title,_content);
        }       
        private void Clear()
        {
            foreach (Transform item in _content)
            {
                GameObject.Destroy(item.gameObject);
            }
        }
    }
}