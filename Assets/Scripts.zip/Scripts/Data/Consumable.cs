﻿

namespace FactoryManager.Data
{   
    /// <summary>
    /// Расходный материал
    /// </summary>
    public class Consumable : TableItem
    {        
    }
}