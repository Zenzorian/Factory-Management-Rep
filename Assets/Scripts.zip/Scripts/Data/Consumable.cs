﻿

namespace FactoryManager.Data
{   
    /// <summary>
    /// Расходный материал
    /// </summary>
    public class Consumable : TableItem
    {
        public override string Type { get; set; }
    }
}