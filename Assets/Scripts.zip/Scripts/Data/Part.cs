using FactoryManager.Data.Tools;
using System.Collections.Generic;

namespace FactoryManager.Data
{
    /// <summary>
    /// �������� ������
    /// </summary>
    [System.Serializable]
    public class Part : TableItem
    {
        public string Name;        
        public List<Statistics> Statistics = new List<Statistics>();
        public Part()
        {

        }
        public Part(string name, string partType)
        {
            Name = name;
            Type = partType;            
        }
    }
    [System.Serializable]
    public class Statistics
    {
        public Statistics(Tool tool, ProcessingType processingType)
        {
            Tool = tool;
            ProcessingType = processingType;
        }

        public Tool Tool;
        public ProcessingType ProcessingType;
        public List<StatisticData> Data;
    }
    [System.Serializable]
    public enum ProcessingType
    {
        Finishing, 
        Roughing,
        NotSpecified
    }
    [System.Serializable]
    public class StatisticData
    {
        public double FMin;
        public double VMin;
        public List<int> PartCount;

    }
}