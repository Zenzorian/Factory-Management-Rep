namespace FactoryManager.Data
{
    [System.Serializable]
    public abstract class TableItem
    {
        public string Type;
    }
}