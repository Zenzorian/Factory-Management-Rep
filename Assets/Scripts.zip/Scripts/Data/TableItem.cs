namespace FactoryManager.Data
{
    public abstract class TableItem
    {
        public abstract string Type { get; set; }
    }
}