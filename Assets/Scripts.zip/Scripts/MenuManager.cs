using FactoryManager.Data;
using FactoryManager.Data.Tools;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
namespace FactoryManager
{
    public class MenuManager : MonoBehaviour
    {
        public static MenuManager instance;
        public MainMenuTypes menuType;

        public UnityEvent<Part> OnPartSelected;
        public UnityEvent<Tool> OnToolSelected;

        [SerializeField] private GlobalData _globalData;
        [SerializeField] private Transform _mainMenu;       

        [SerializeField] private Transform _choicePanel;

        [SerializeField] private Transform _addationPanel;
        [SerializeField] private Transform _tableView;
        [SerializeField] private Transform _optionsPanel;
        [SerializeField] private Transform _statisticPanel;
        [SerializeField] private ChoiceOfCategoryMenu _categoryMenu;

        [SerializeField] private StatisticsPanelController _statisticsPanelController;
        [SerializeField] private ConfirmationPanel _confirmationPanel;

        private GameObject[] _menuStack = new GameObject[4];
        private int _menuIndex = 0;

       

        private bool _StatisticisOpen;

        private void Awake()
        {
            if (instance == null)
            instance = this;

            _menuStack[0] = _mainMenu.gameObject;
            AddationManager.instance.OnAdded.AddListener(Back);
            OnPartSelected.AddListener(PartSelected);
            OnToolSelected.AddListener(ToolSelected);
        }
        private void Update()
        {
            if (Input.GetKeyDown(KeyCode.Escape))
            {
                Back();
            }
        }
        private void Back()
        {
            if (_menuIndex == 0) return;

            _menuStack[_menuIndex].SetActive(false);
            _menuIndex--;
            _menuStack[_menuIndex].SetActive(true);
        }
        private void Forwards(GameObject gameObject)
        {
            _menuStack[_menuIndex].SetActive(false);
            _menuIndex++;
            gameObject.SetActive(true);
            _menuStack[_menuIndex] = gameObject;
        }
        public void OpenMenu(int value)
        {            
            menuType = (MainMenuTypes)value;
            List<string> selectedList = null;

            switch (menuType)
            {
                case MainMenuTypes.Workspace:
                    selectedList = _globalData.typesOfWorkspaces;
                    break;
                case MainMenuTypes.Tools:
                    selectedList = _globalData.typesOfTools;
                    break;
                case MainMenuTypes.Workers:
                    selectedList = _globalData.typesOfWorkers;
                    break;
                case MainMenuTypes.Parts:
                    selectedList = _globalData.typesOfParts;
                    break;
                case MainMenuTypes.Statistic:
                    Forwards(_statisticPanel.gameObject); 
                    break;
                case MainMenuTypes.StatisticPart:
                    selectedList = _globalData.typesOfParts; 
                    break;
                case MainMenuTypes.StatisticTool:
                    selectedList = _globalData.typesOfTools;
                    break;
                case MainMenuTypes.Options:
                    Forwards(_optionsPanel.gameObject);
                    return;
                default:
                    break;
            }

            if (selectedList != null)
            {
                _categoryMenu.Create(selectedList, menuType);
                Forwards(_choicePanel.gameObject);
            }
        }
        public void OpenListsMenu()
        {
            //Forwards(_listsMenu.gameObject);
        }
        public void OpenAddationPanel()
        {
            Forwards(_addationPanel.gameObject);
        }
        public void OpenTableView()
        {
            Forwards(_tableView.gameObject);
        }
        public void OpenProcessingTypeMenu(int index)
        {
            var part = _globalData.listOfParts[index];
            //_categoryMenu.Create(part., MainMenuTypes.Statistic);
            Forwards(_choicePanel.gameObject);
        }
        public void PartSelected(Part part)
        {
            Debug.Log(menuType);
            if (menuType != MainMenuTypes.StatisticPart) return;
            Back();
            Back();

            _statisticsPanelController.OnPartSelected(part);
        }
        public void ToolSelected(Tool tool)
        {
            if (menuType != MainMenuTypes.StatisticTool) return;
            Back();
            Back();
            _statisticsPanelController.OnToolSelected(tool);
        }
        public void ShowConfirmationPanel()
        {
            _confirmationPanel.Show();
        }
    }
    public enum MainMenuTypes
    {
        Workspace,
        Tools,
        Workers,
        Parts,
        Statistic,
        Options = 99,
        StatisticPart,
        StatisticTool
    }
}