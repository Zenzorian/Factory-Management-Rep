using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;
using FactoryManager.Data;
using FactoryManager;
using FactoryManager.Data.Tools;
using NUnit.Framework;
using static UnityEditor.Progress;

public class StatisticsPanelController : MonoBehaviour
{
    [SerializeField] private GlobalData _globalData;

    [SerializeField] private Text _partText;
    [SerializeField] private Button _selectPartButton;
    [SerializeField] private Text _processingTypeText;
    [SerializeField] private Dropdown _processingTypeDropdown;
    [SerializeField] private Text _toolText;
    [SerializeField] private Button _selectToolButton;
    [SerializeField] private Button _goToStatisticsButton;
    
    private Part _selectedPart;
    private Tool _selectedTool;
    private ProcessingType _selectedProcessingType;

    private void Start()
    {
        _partText.text = "Part";
        _selectPartButton.GetComponentInChildren<Text>().text = "Select Part";

        _processingTypeText.text = "Select Processing Type";

        _toolText.text = "Tool";
        _selectToolButton.GetComponentInChildren<Text>().text = "Select Tool";
        _goToStatisticsButton.GetComponentInChildren<Text>().text = "Go to Statistics";

        _selectPartButton.onClick.AddListener(PartButtonClicked);
        _selectToolButton.onClick.AddListener(ToolButtonClicked);
        _goToStatisticsButton.onClick.AddListener(OnGoToStatisticsButtonClicked);

        _processingTypeText.gameObject.SetActive(false);
        _processingTypeDropdown.gameObject.SetActive(false);
        _toolText.gameObject.SetActive(false);
        _selectToolButton.gameObject.SetActive(false);
        _goToStatisticsButton.gameObject.SetActive(false);

        ConfirmationPanel.instance.OnConfirmed.AddListener(OnConfirmation);

    }

    private void PartButtonClicked()
    {
        MenuManager.instance.OpenMenu((int)MainMenuTypes.StatisticPart);
    }
    public void OnPartSelected(Part part)
    {
        _selectedPart = part;
        _partText.text = $"Selected Part: {_selectedPart.Name}";
        ShowProcessingTypeDropdown();
        
    }

    private void ShowProcessingTypeDropdown()
    {
        _processingTypeDropdown.gameObject.SetActive(true);
        _processingTypeText.gameObject.SetActive(true);
        _processingTypeDropdown.ClearOptions();
        List<string> processingTypes = new List<string>();

        foreach (var type in System.Enum.GetValues(typeof(ProcessingType)))
        {
            processingTypes.Add(type.ToString());
        }

        _processingTypeDropdown.AddOptions(processingTypes);
        _processingTypeDropdown.onValueChanged.AddListener(OnProcessingTypeSelected);
    }

    private void OnProcessingTypeSelected(int index)
    {
        _selectedProcessingType = (ProcessingType)index;
        _toolText.gameObject.SetActive(true);
        _selectToolButton.gameObject.SetActive(true);
    }

    private void ToolButtonClicked()
    {
        MenuManager.instance.OpenMenu((int)MainMenuTypes.StatisticTool);
    }
    public void OnToolSelected(Tool tool)
    {
        _selectedTool = tool;
        _toolText.text = $"Selected Tool: {_selectedTool.Marking}";
        _goToStatisticsButton.gameObject.SetActive(true);
    }
    private void OnGoToStatisticsButtonClicked()
    { 
        if (_selectedPart.Statistics.Count == 0 || _selectedPart.Statistics == null)
        {
            OpenConfirmationAndAddationMenu();
            return;
        }
       
        foreach (var item in _selectedPart.Statistics)
        {
            if (item.ProcessingType == _selectedProcessingType && item.Tool == _selectedTool)
            {
                OpenCurrentStatistic(item);
                return;
            }
        }
        OpenConfirmationAndAddationMenu();       
    }   
    private void OpenConfirmationAndAddationMenu()
    {
        MenuManager.instance.ShowConfirmationPanel();
    }
    private void OpenCurrentStatistic(Statistics statistics)
    {

    }
    private void OnConfirmation()
    {
        _selectedPart.Statistics.Add(new Statistics(_selectedTool, _selectedProcessingType));        
    }
}
