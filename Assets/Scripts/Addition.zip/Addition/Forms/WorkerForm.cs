using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class WorkerForm : MonoBehaviour
{
    [SerializeField] private InputField _IdInputField;

    [SerializeField] private Dropdown _typeDropdown;

    [SerializeField] private InputField _firstNameInputField;
    [SerializeField] private InputField _lastNameInputField;

    [SerializeField] private InputField _weeklyNormInputField;
    [SerializeField] private InputField _overtimeAllowedInputField;

    [SerializeField] private InputField _hourlyWageInputField;
    [SerializeField] private InputField _overtimeSurchargeInputField;
    [SerializeField] private InputField _nightShiftSurchargeInputField;
        
}
